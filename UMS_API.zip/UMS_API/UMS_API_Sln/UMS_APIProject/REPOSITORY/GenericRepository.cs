﻿using COMMON.UMSENTITIY;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace UMS_APIProject.REPOSITORY
{
    public class GenericRepository<T> : IRepository<T> where T : class
    {
        private readonly IConfiguration _config;
        private string context = "CKCENTITY";

        public GenericRepository(IConfiguration config)
        {
            this._config = config;
        }

        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if(!this.disposed)
            {
                if(disposing)
                {
                    
                }
            }
        }
        public void Dispose()
        {
            //Dispose(true);
            GC.SuppressFinalize(this);
        }
        public T Insert<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            T result;
            using (IDbConnection db= new SqlConnection(_config.GetConnectionString(context)))
            try
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using (var tran = db.BeginTransaction())
                try
                {
                    result = db.Query<T>(sp, parms, commandType: commandType, transaction: tran).FirstOrDefault();
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }

            return result;
        }
        public T Update<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            T result;
            using (IDbConnection db = new SqlConnection(_config.GetConnectionString(context)))
            try
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                    using (var tran = db.BeginTransaction())
                try
                {
                    result = db.Query<T>(sp, parms, commandType: commandType, transaction: tran).FirstOrDefault();
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }

            return result;
        
    }
    public T ExecuteQuerySingle(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            T result;
           
            using (IDbConnection dbConnection = new SqlConnection(_config.GetConnectionString(context)))
            {
                if (dbConnection.State == ConnectionState.Closed)
                    dbConnection.Open();
                var transaction = dbConnection.BeginTransaction();
                try
                {
                    result= dbConnection.Query<T>(sp, parms, commandType: commandType, transaction: transaction).FirstOrDefault();
                    // dbConnection.Query<T>(sp, parms, commandType: commandType, transaction: transaction);
                    //result = parms.Get<T>("@UserName");
                    //transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw ex;
                }
            };
           return result;
        }

         public List<T> ExecuteQuery(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
           
            using (IDbConnection dbConnection = new SqlConnection(_config.GetConnectionString(context)))
            {
                if (dbConnection.State == ConnectionState.Closed)
                    dbConnection.Open();
                var transaction = dbConnection.BeginTransaction();
                try
                {
                    return dbConnection.Query<T>(sp, parms, commandType: commandType, transaction: transaction).ToList();
                   // dbConnection.Query<T>(sp, parms, commandType: commandType, transaction: transaction);
                   // result = parms.Get<T>("");
                   // transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw ex;
                }
            };
        }

        public List<T> ExecuteSingleQuery(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {

            using (IDbConnection dbConnection = new SqlConnection(_config.GetConnectionString(context)))
            {
                if (dbConnection.State == ConnectionState.Closed)
                    dbConnection.Open();
                var transaction = dbConnection.BeginTransaction();
                try
                {
                    return dbConnection.Query<T>(sp, parms, commandType: commandType, transaction: transaction).ToList();
                    // dbConnection.Query<T>(sp, parms, commandType: commandType, transaction: transaction);
                    // result = parms.Get<T>("");
                    // transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw ex;
                }
            };
        }
    }
}
