﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace UMS_APIProject.REPOSITORY
{
   public interface IRepository<T>:IDisposable where  T:class
    {
        T Insert<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);

        T Update<T>(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);

        T ExecuteQuerySingle(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);
        List<T> ExecuteQuery(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);

        List<T> ExecuteSingleQuery(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);

    }
}
