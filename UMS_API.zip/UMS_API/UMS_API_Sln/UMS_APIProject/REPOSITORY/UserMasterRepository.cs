﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using COMMON;
using COMMON.UMSENTITIY;
using Dapper;
using Microsoft.Extensions.Configuration;
using UMS_APIProject.INTERFACE;

namespace UMS_APIProject.REPOSITORY
{
    public class UserMasterRepository : IUserMasters
    {
        private readonly IConfiguration _config;
        private string context = "CKCENTITY";

        public UserMasterRepository(IConfiguration config)
        {
            this._config = config;
        }
        public IDbConnection connection {

            get
            {
                return new SqlConnection(_config.GetConnectionString(context));
            }

        }

        public async Task<GResponse> AddUserMaster(UserMaster usermaster)
        {
            try
            {
                using (IDbConnection con = connection)
                {
                    //string sQuery = "USP_Customer";
                    con.Open();
                    var dbPara = new DynamicParameters();
                    dbPara.Add("@UserName", usermaster.UserName);
                    dbPara.Add("@UserPass", usermaster.UserPass);
                    dbPara.Add("@EmpCode", usermaster.EmpCode);
                    dbPara.Add("@CreatedBy", usermaster.UserName);

                    var result = await con.QueryAsync<GResponse>(StoredProcedureHelper.spInsertUserMaster, dbPara, commandType: CommandType.StoredProcedure);
                    return result.FirstOrDefault();


                }
            }
            catch (Exception ex)
            { throw ex; }
        }

        //public Task<UserMaster> AddUserMaster(UserMaster usermaster)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
