﻿using System;
using System.Threading.Tasks;
using COMMON.UMSENTITIY;
using Dapper;
using UMS_APIProject.FILTERS;
using UMS_APIProject.INTERFACE;
using Microsoft.AspNetCore.Mvc;
using COMMON;
using System.Data;
using UMS_APIProject.DAL;
using System.Linq;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace UMS_APIProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private IUser<LoginDetails,Userdata,Data> _dataRepository;
        private IUMSMaster<UserMaster, GResponse,BranchMaster> _masterRepository;
        private readonly IConfiguration _config;
       // private string context = "CKCENTITY";
        public UserController(IUser<LoginDetails,Userdata,Data> dataRepository, IConfiguration config, IUMSMaster<UserMaster,GResponse, BranchMaster> masterRepository)
        {
            this._dataRepository = dataRepository;
            this._config = config;
            this._masterRepository = masterRepository;
        }
        //[HttpGet]
        //[Route("Login")]
        //[ServiceFilter(typeof(SLog))]
        //public async Task<IActionResult> Login(string UserName, string Password)
        //{
        //    try
        //    {
                
        //        var Token = await Task.Run(() => TokenHelper.GenerateToken(UserName));
        //        var dbPara = new DynamicParameters();
        //        dbPara.Add("@UserName", UserName);
        //        dbPara.Add("@Password", Password);
        //        dbPara.Add("@UserSalt", "");
        //        dbPara.Add("@PassSalt", "");
        //        dbPara.Add("@Token", Token);
        //        var result = await Task.FromResult(_dataRepository.Login(StoredProcedureHelper.NBFC_SP_ValidateUserDemo_vip, dbPara, commandType: CommandType.StoredProcedure));
        //        if(result.status==1)    
        //        {
        //            return Ok(result);
        //        }
        //        else
        //        {

        //            //List<GResponse> _lst = _masterRepository.GResponse(StoredProcedureHelper.NBFC_SP_ValidateUserDemo_vip, dbPara, commandType: CommandType.StoredProcedure);
        //            //return Ok(_lst);
        //            return Ok(result);
        //        }
               
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //}
    }
}