﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using COMMON;
using COMMON.UMSENTITIY;
using Dapper;
using UMS_APIProject.FILTERS;
using UMS_APIProject.INTERFACE;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UMS_APIProject.REPOSITORY;

namespace UMS_APIProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UMSMasterController : ControllerBase
    {
        private IUMSMaster<UserMaster, GResponse, BranchMaster> _masterRepository;
        private readonly ILogger<UMSMasterController> _logger;
        private readonly IConfiguration _config;
        //private readonly IUserMasters _userMasterRepository;
        public UMSMasterController(ILogger<UMSMasterController> logger, IUMSMaster<UserMaster, GResponse, BranchMaster> masterRepository, IConfiguration config)
        {
            this._masterRepository = masterRepository;
            this._logger = logger;
            this._config = config;
            //this._userMasterRepository = userMastersRepository;
        }

        //[HttpPost]
        //[Route("AddUserMaster")]
        //[ServiceFilter(typeof(SLog))]
        //public async Task<ActionResult<GResponse>> AddUserMaster([FromBody] UserMaster userMaster)
        //{
        //    try
        //    {
        //        if (userMaster == null || !ModelState.IsValid)
        //        {
        //            return BadRequest("Invalid State");
        //        }


        //        return await _userMasterRepository.AddUserMaster(userMaster);
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //}
        #region UserMaster
        [HttpPost]
        [Route("AddUserMaster")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> AddUserMaster([FromBody] UserMaster userMaster)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("@UserName", userMaster.UserName);
                dbPara.Add("@UserPass", userMaster.UserPass);
                dbPara.Add("@EmpCode", userMaster.EmpCode);
                dbPara.Add("@CreatedBy", userMaster.UserName);
                GResponse result = await Task.FromResult(_masterRepository.AddUserMaster(StoredProcedureHelper.spInsertUserMaster, dbPara, commandType: CommandType.StoredProcedure));


                return Ok(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("GetUserMasterById")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> GetUserMasterById(int? ID_User)
        {
            try
            {

                var dbPara = new DynamicParameters();
                dbPara.Add("@ID_User", ID_User);
                var result = await Task.FromResult(_masterRepository.GetUserMasterById(StoredProcedureHelper.spGetUserMasterByID, dbPara, commandType: CommandType.StoredProcedure));

                if (result != null)
                {
                    return Ok(result);
                }
                return Ok(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPatch]
        [Route("IsActiveDeactiveUser")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> IsActiveDeactiveUser(string ID_User, int IsActive)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("@ID_User", ID_User);
                dbPara.Add("@IsActive", IsActive);
                GResponse result = await Task.FromResult(_masterRepository.ActiveDeactiveUser(StoredProcedureHelper.spDeleteUserMaster, dbPara, commandType: CommandType.StoredProcedure));
                return Ok(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPatch]
        [Route("UpdateUserMaster")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> UpdateUserMaster([FromBody] UserMaster userMaster)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("@ID_User", userMaster.ID_User);
                dbPara.Add("@UserName", userMaster.UserName);
                dbPara.Add("@UserPass", userMaster.UserPass);
                dbPara.Add("@EmpCode", userMaster.EmpCode);
                dbPara.Add("@Modifiedby", userMaster.UserName);
                GResponse result = await Task.FromResult(_masterRepository.UPDATEUSERMASTER(StoredProcedureHelper.spUpdateUserMaster, dbPara, commandType: CommandType.StoredProcedure));
                return Ok(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpGet]
        [Route("GetAllUserMasterDetails")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> GetAllUserMasterDetails()
        {
            try
            {
                var dbPara = new DynamicParameters();
                var result = await Task.FromResult(_masterRepository.GetUserMaster(StoredProcedureHelper.spGetUserMaster, dbPara, commandType: CommandType.StoredProcedure));
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {

                    return Ok(result);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion

        #region BranchMaster

        [HttpPost]
        [Route("AddBranchMaster")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> AddBranchMaster([FromBody] BranchMaster branchMaster)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("@Code", branchMaster.Code);
                dbPara.Add("@Name", branchMaster.Name);
                dbPara.Add("@CreatedBy", branchMaster.Name);
                dbPara.Add("@IsActive", branchMaster.IsActive);
                GResponse result = await Task.FromResult(_masterRepository.AddBranchMaster(StoredProcedureHelper.spInsertBranchMaster, dbPara, commandType: CommandType.StoredProcedure));


                return Ok(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("GetBranchMasterById")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> GetBranchMasterById(int? ID_Branch)
        {
            try
            {

                var dbPara = new DynamicParameters();
                dbPara.Add("@ID_Branch", ID_Branch);
                var result = await Task.FromResult(_masterRepository.GetBranchMasterById(StoredProcedureHelper.spGetBranchMasterByID, dbPara, commandType: CommandType.StoredProcedure));

                if (result != null)
                {
                    return Ok(result);
                }
                return Ok(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPatch]
        [Route("IsActiveDeactiveBranch")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> IsActiveDeactiveBranch(string ID_Branch, int IsActive)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("@ID_Branch", ID_Branch);
                dbPara.Add("@IsActive", IsActive);
                GResponse result = await Task.FromResult(_masterRepository.ActiveDeactiveBranch(StoredProcedureHelper.spDeleteBranchMaster, dbPara, commandType: CommandType.StoredProcedure));
                return Ok(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpPatch]
        [Route("UpdateBranchMaster")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> UpdateBranchMaster([FromBody] BranchMaster branchMaster)
        {
            try
            {
                var dbPara = new DynamicParameters();
                dbPara.Add("@ID_Branch", branchMaster.ID_Branch);
                dbPara.Add("@Code", branchMaster.Code);
                dbPara.Add("@Name", branchMaster.Name);
                GResponse result = await Task.FromResult(_masterRepository.UPDATEBranchMaster(StoredProcedureHelper.spUpdateBranchMaster, dbPara, commandType: CommandType.StoredProcedure));
                return Ok(result);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        [HttpGet]
        [Route("GetAllBranchMasterDetails")]
        [ServiceFilter(typeof(SLog))]
        public async Task<IActionResult> GetAllBranchMasterDetails()
        {
            try
            {
                var dbPara = new DynamicParameters();
                var result = await Task.FromResult(_masterRepository.GetBranchMaster(StoredProcedureHelper.spGetBranchMaster, dbPara, commandType: CommandType.StoredProcedure));
                if (result != null)
                {
                    return Ok(result);
                }
                else
                {

                    return Ok(result);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion
        //    [HttpGet]
        //    [Route("BorrowerType")]
        //    [ServiceFilter(typeof(SLog))]
        //    public async Task<IActionResult> BorrowerType(int Id, string Code, string Type)
        //    {
        //        try
        //        {

        //            var dbPara = new DynamicParameters();

        //            dbPara.Add("@Id", Id);
        //            dbPara.Add("@Code", Code);
        //            dbPara.Add("@Type", Type);
        //            var result = await Task.FromResult(_masterRepository.BorrowerType(StoredProcedureHelper.SP_ViewBorrowerType_vip, dbPara, commandType: CommandType.StoredProcedure));

        //            if (result[0].Id != 0)
        //            {
        //                return Ok(result);
        //            }
        //            else
        //            {
        //                List<GResponse> _lst = _masterRepository.GResponse(StoredProcedureHelper.SP_ViewBorrowerType_vip, dbPara, commandType: CommandType.StoredProcedure);
        //                return Ok(_lst);
        //            }
        //        }
        //        catch (Exception ex)
        //        {

        //            throw ex;
        //        }
        //    }

        //    [HttpGet]
        //    [Route("FillLoanPurposes")]
        //    [ServiceFilter(typeof(SLog))]
        //    public async Task<IActionResult> FillLoanPurposes()
        //    {
        //        try
        //        {

        //            var dbPara = new DynamicParameters();

        //            var result = await Task.FromResult(_masterRepository.LoanPurpose(StoredProcedureHelper.SP_GetLoanpurpose_vip, dbPara, commandType: CommandType.StoredProcedure));

        //            if (result[0].Code != null)
        //            {
        //                return Ok(result);
        //            }
        //            else
        //            {
        //                List<GResponse> _lst = _masterRepository.GResponse(StoredProcedureHelper.SP_GetLoanpurpose_vip, dbPara, commandType: CommandType.StoredProcedure);
        //                return Ok(_lst);
        //            }
        //        }
        //        catch (Exception ex)
        //        {

        //            throw ex;
        //        }
        //    }

        //    [HttpGet]
        //    [Route("GetBranch")]
        //    [ServiceFilter(typeof(SLog))]
        //    public async Task<IActionResult> GetBranch(string prefixText)
        //    {
        //        try
        //        {

        //            var dbPara = new DynamicParameters();
        //            dbPara.Add("@BCode", prefixText);
        //            var result = await Task.FromResult(_masterRepository.GetBranch(StoredProcedureHelper.Sp_GetBranchPrefix_vip, dbPara, commandType: CommandType.StoredProcedure));

        //            if (result[0].BNCode != null)
        //            {
        //                return Ok(result);
        //            }
        //            else
        //            {
        //                List<GResponse> _lst = _masterRepository.GResponse(StoredProcedureHelper.Sp_GetBranchPrefix_vip, dbPara, commandType: CommandType.StoredProcedure);
        //                return Ok(_lst);
        //            }
        //        }
        //        catch (Exception ex)
        //        {

        //            throw ex;
        //        }
        //    }



        //}
    }
}