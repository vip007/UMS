﻿using COMMON.UMSENTITIY;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UMS_APIProject.INTERFACE
{
    public interface IUserMasters
    {
        Task<GResponse> AddUserMaster(UserMaster usermaster);
    }
}
