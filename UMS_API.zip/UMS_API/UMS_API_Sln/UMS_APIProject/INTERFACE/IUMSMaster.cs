﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace UMS_APIProject.INTERFACE
{
    public interface IUMSMaster<T,T1,T2>
    {
        List<T> GetUserMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);
        List<T> GetUserMasterById(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);
        T1 Gresponse(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);
        T1 AddUserMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);
        T1 ActiveDeactiveUser(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);
        T1 UPDATEUSERMASTER(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);

        T1 AddBranchMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);

        T1 ActiveDeactiveBranch(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);
        T1 UPDATEBranchMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);
        List<T2> GetBranchMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);

        List<T2> GetBranchMasterById(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure);



    }
}
