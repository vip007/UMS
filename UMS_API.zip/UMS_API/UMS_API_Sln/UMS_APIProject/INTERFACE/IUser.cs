﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace UMS_APIProject.INTERFACE
{
    public interface IUser<T,T1,T2>
    {
        T Login(string sp, DynamicParameters parms, CommandType commandType=CommandType.StoredProcedure);
    }
}
