﻿using COMMON.UMSENTITIY;
using Dapper;
using UMS_APIProject.INTERFACE;
using UMS_APIProject.REPOSITORY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace UMS_APIProject.SERVICES
{
    public class UMSMasterService : IUMSMaster<UserMaster,GResponse,BranchMaster>
    {
        private IRepository<UserMaster> _usermasterRepository;
        private IRepository<GResponse> _gresponseRepository;
        private IRepository<BranchMaster> _branchmasterRepository;
        public UMSMasterService(IRepository<UserMaster> usermasterRepository,IRepository<GResponse> gresponseRepository, IRepository<BranchMaster> branchmasterRepository)
        {
            this._usermasterRepository = usermasterRepository;
           
            this._gresponseRepository = gresponseRepository;
            this._branchmasterRepository = branchmasterRepository;
        }

        public GResponse ActiveDeactiveBranch(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _branchmasterRepository.Update<GResponse>(sp, parms, CommandType.StoredProcedure);
        }

        public GResponse ActiveDeactiveUser(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _gresponseRepository.Update<GResponse>(sp, parms, CommandType.StoredProcedure);
        }

        public GResponse AddBranchMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _branchmasterRepository.Insert<GResponse>(sp, parms, CommandType.StoredProcedure);
        }

        public GResponse AddUserMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _gresponseRepository.Insert<GResponse>(sp, parms, CommandType.StoredProcedure);
        }

        public List<BranchMaster> GetBranchMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _branchmasterRepository.ExecuteQuery(sp, parms, CommandType.StoredProcedure);
        }

        public List<BranchMaster> GetBranchMasterById(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _branchmasterRepository.ExecuteQuery(sp, parms, CommandType.StoredProcedure);
        }

        public List<UserMaster> GetUserMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _usermasterRepository.ExecuteQuery(sp, parms, CommandType.StoredProcedure);
        }

        public List<UserMaster> GetUserMasterById(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _usermasterRepository.ExecuteQuery(sp, parms, CommandType.StoredProcedure);

        }

        public GResponse Gresponse(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _gresponseRepository.ExecuteQuerySingle(sp, parms, CommandType.StoredProcedure);
        }

        public GResponse UPDATEBranchMaster(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _gresponseRepository.Update<GResponse>(sp, parms, CommandType.StoredProcedure);
        }

        public GResponse UPDATEUSERMASTER(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return _gresponseRepository.Update<GResponse>(sp, parms, CommandType.StoredProcedure);
        }
    }
}
