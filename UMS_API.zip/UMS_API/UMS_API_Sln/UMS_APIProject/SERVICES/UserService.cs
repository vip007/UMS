﻿using COMMON.UMSENTITIY;
using Dapper;
using UMS_APIProject.INTERFACE;
using UMS_APIProject.REPOSITORY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace UMS_APIProject.SERVICES
{
    public class UserService : IUser<LoginDetails,Userdata,Data>
    {
        private IRepository<LoginDetails> LoginRepository;
       // private IRepository<Userdata> LoginRepository1;
        //private IRepository<Data> LoginRepository2;
        public UserService(IRepository<LoginDetails> loginRepository)
        {
            this.LoginRepository = loginRepository;
        }
        public LoginDetails Login(string sp, DynamicParameters parms, CommandType commandType = CommandType.StoredProcedure)
        {
            return LoginRepository.ExecuteQuerySingle(sp, parms, CommandType.StoredProcedure);

        }
    }
}
