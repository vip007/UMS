﻿using COMMON.UMSENTITIY;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UMS_APIProject.DAL
{
    public class CKCConext:DbContext
    {
        public CKCConext()
        {


        }
        public CKCConext(DbContextOptions<CKCConext> options):base(options)
        {
           

        }
        public DbSet<LoginDetails> LoginDetails { get; set; }
    }
}
