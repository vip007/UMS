﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace UMS_APIProject.FILTERS
{
    public class SLog : Microsoft.AspNetCore.Mvc.Filters.IActionFilter
    {
        private ILogger _logger;
        public SLog(ILoggerFactory loggerFactory)
        {
            this._logger = loggerFactory.CreateLogger<SLog>();
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
            _logger.LogInformation($"Action '{context.ActionDescriptor.DisplayName}' executed");
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            var response = context.HttpContext.Response;
            _logger.LogInformation(string.Format("Action Method {0} executing at {1}", context.ActionDescriptor.DisplayName, DateTime.Now.ToShortDateString()));
            foreach(var item in context.ActionArguments)
            {
                _logger.LogInformation(string.Format("Action Method parameter {1}", context.ActionDescriptor.DisplayName, item.Key + JsonConvert.SerializeObject(item.Value)));
            }
        }
    }
}
