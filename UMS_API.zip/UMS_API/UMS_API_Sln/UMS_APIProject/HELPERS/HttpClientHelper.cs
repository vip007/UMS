﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UMS_APIProject;

namespace UMS_APIProject.HELPERS
{
    public class HttpClientHelper<T>
    {
        static string apiBaseUrl = Startup.StaticConfig.GetValue<string>("WebAPIBaseUrl");
        static string BasicAuth = "Basic" + Convert.ToBase64String(Encoding.Default.GetBytes("LOS:LOS#2021"));

        public T GetSingleItemRequest(string apiUrl)
        {
            string endpoint = apiBaseUrl + apiUrl;
            var result1 = default(T);
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", BasicAuth);
                using (var Response = client.GetAsync(endpoint))
                {
                    Response.Wait();
                    var result = Response.Result;
                    if(result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();
                        result1 = JsonConvert.DeserializeObject<T>(readTask.Result);
                    }
                }
            }
                return result1;
        }

    }
}
