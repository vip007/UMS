﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace COMMON.UMSENTITIY
{
    public class UserMaster
    {
       [Key]
        public int ID_User { get; set; }
        public string UserName { get; set; }
        public string UserPass { get; set; }
        public string EmpCode { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsActive { get; set; }
    }
    public class BranchMaster
    {
        public string ID_Branch { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsActive { get; set; }
    }

    //public class LoanApplicationType
    //{
    //   public string  NC_ID { get; set; }
    //   public string Description { get; set; }
    //}

    //public class BorrowerType
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }

    //}
    //public class LoanPurpose
    //{
    //    public string Code { get; set; }
    //    public string Name { get; set; }
    //}
    //public class GetBranch
    //{
    //    public string BNCode { get; set; }
    //}
    //public class SalesPerson
    //{
    //    public string ID { get; set; }
    //    public string Code { get; set; }
    //    public string Pan { get; set; }
    //    public string ApplicationNo { get; set; }
    //    public string EmailID { get; set; }
    //    public string LoginNo { get; set; }
    //    public string ApplicantName { get; set; }
    //    public string Mobile { get; set; }
    //    public string Name { get; set; }
    //    public string Doj { get; set; }
    //    public string Department { get; set; }
    //    public string Designation { get; set; }
    //    public string Location { get; set; }
    //}
    public class GResponse
    {
        public int status { get; set; }
        public string message { get; set; }

    }
}
