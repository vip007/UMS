﻿using System;

namespace COMMON.UMSENTITIY
{


    public class LoginDetails
    {
        public int status { get; set; }
        public string message { get; set; }

        [Obsolete]
        public string UserName { get; set; }
        public string Emailid { get; set; }
       // public string UserSalt { get; set; }
        //public string PasswordSalt { get; set; }
        public string Token { get; set; }
        // public Data data { get; set; }
    }

    public class Userdata
    {
        public int ID_User { get; set; }
        public string UserName { get; set; }
        public string Code { get; set; }
        public int ID_UserType { get; set; }
        public bool IsActive { get; set; }
    }

    public class Data
    {
        public Userdata userdata { get; set; }
        public string accessToken { get; set; }
    }

}
