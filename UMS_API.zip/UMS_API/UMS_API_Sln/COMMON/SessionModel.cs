﻿using System;
using System.Collections.Generic;
using System.Text;

namespace COMMON
{
   public class SessionModel
    {
        public string Session_Val { get; set; }
    }
}
