﻿using System;
using System.Collections.Generic;
using System.Text;

namespace COMMON
{
   public static class CommonHelper
    {
        private static object lockObject { get; set; }
        public static object LockObject {

            get
            {
                if (lockObject == null)
                    lockObject = new object();
                return lockObject;
            }
        }
    }
}
