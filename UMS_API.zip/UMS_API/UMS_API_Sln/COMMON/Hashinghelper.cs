﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
namespace COMMON
{
    public class Hashinghelper
    {
        public static string Hashusingpbkdf2_UserSalt(string UserName, string salt)
        {
               var bytes = new Rfc2898DeriveBytes(UserName,Convert.FromBase64String(salt), 10000, HashAlgorithmName.SHA256);
                var derivedRondomKey = bytes.GetBytes(32);
                var hash = Convert.ToBase64String(derivedRondomKey);
                return hash;
        }

        public static string Hashusingpbkdf2_PasswordSalt(string password, string salt)
        {
            var bytes = new Rfc2898DeriveBytes(password, Convert.FromBase64String(salt), 10000, HashAlgorithmName.SHA256);
            var derivedRondomKey = bytes.GetBytes(32);
            var hash = Convert.ToBase64String(derivedRondomKey);
            return hash;
        }
    }
}
