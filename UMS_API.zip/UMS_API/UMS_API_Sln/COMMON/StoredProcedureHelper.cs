﻿using System;
using System.Collections.Generic;
using System.Text;

namespace COMMON
{
    public  class StoredProcedureHelper
    {
        #region UMS Master Stored Procedure
        public const string spInsertUserMaster = "spInsertUserMaster";
        public const string spDeleteUserMaster = "spDeleteUserMaster";
        public const string spUpdateUserMaster = "spUpdateUserMaster";
        public const string spGetUserMaster = "spGetUserMaster";
        public const string spGetUserMasterByID = "spGetUserMasterByID";

        public const string spInsertBranchMaster = "spInsertBranchMaster";
        public const string spDeleteBranchMaster = "spDeleteBranchMaster";
        public const string spUpdateBranchMaster = "spUpdateBranchMaster";
        public const string spGetBranchMaster = "spGetBranchMaster";
        public const string spGetBranchMasterByID = "spGetBranchMasterByID";
        #endregion
    }
}
